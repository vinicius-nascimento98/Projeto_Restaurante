<?php

header('Content-Type: text/html; charset=utf-8');

?>

<!doctype html>

<html lang="pt-BR">
	<head>
		<meta charset="utf-8" />
	</head>
	
	<body>
	
	<a href="Form_Atendente.php">Cadastrar Atendentes</a>
	|
	<a href="Form_Ingrediente.php">Cadastrar Ingredientes</a>
	|
	<a href="Form_Item.php">Cadastrar Item</a>
	|
	<a href="Form_Reserva.php">Cadastrar Reserva</a>
	|
	<a href="Form_Mesa.php">Cadastrar Mesa</a>
	|
	<a href="Listar_Ingrediente.php">Listar Ingredientes</a>
	| 
	<a href="Listar_Lista_Espera.php">Listar Espera</a>
	|
	<a href="Listar_Reserva.php">Listar Reservas</a>
	|
	<a href="Listar_Atendente.php">Listar Atendentes</a>
	|
	<a href="Remover_Mesa.php">Remover Mesa</a>
	|
	<a href="Listar_Estoque.php">Listar Estoque</a>
	|
	<a href="Form_Iniciar_Mesa.php">Iniciar Mesa</a>
	|
	<a href="Form_Pedido.php">Adicionar Pedidos a Mesa</a>
	
	<hr />
	<br />