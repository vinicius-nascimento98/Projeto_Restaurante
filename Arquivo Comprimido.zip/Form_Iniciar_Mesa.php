<?php

	include("Class/View/Form/ClassForm.php");
	include("Cabecalho/Cabecalho.php");
    include("Class/Control/ClassBD.php");

	echo "<h2> Iniciar Mesa </h2>";
	
    

?>