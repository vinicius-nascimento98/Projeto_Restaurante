<?php

    header("Location:Form_Atendente.php");

?>