﻿<script>
	window.alert("Mesa removida com sucesso!!");
	location.href='index.php';
</script>
