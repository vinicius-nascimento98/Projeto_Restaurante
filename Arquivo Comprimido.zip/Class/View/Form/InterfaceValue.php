<?php
	
	interface Value{
		
		public function set_value();
		
	}
?>