<?php
	
	interface Tag{
		
		public function set_tag();
		public function get_tag();
				
	}
?>